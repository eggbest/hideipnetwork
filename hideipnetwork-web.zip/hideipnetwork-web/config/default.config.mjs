import dotEnv from 'dotenv';
dotEnv.config();

export default process.env