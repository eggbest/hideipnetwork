export const whiteList = [
    "/api/v1/signin",
    "/api/v1/signup",
    "/api/v1/checkSite",
    "/api/v1/info",
    "/api/v1/checkPwd"
]